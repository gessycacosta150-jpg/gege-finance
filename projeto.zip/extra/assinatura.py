# Liga a chave fixa do app ao build de release, para cada versão instalar por cima da anterior.
p = 'android/app/build.gradle'; s = open(p).read()
if 'signingConfigs' not in s:
    s = s.replace("android {", "def ksFile = file('keystore.properties')\ndef ks = new Properties()\nif (ksFile.exists()) { ks.load(new FileInputStream(ksFile)) }\n\nandroid {", 1)
    s = s.replace("    buildTypes {", "    signingConfigs {\n        release {\n            storeFile file(ks['storeFile'])\n            storePassword ks['storePassword']\n            keyAlias ks['keyAlias']\n            keyPassword ks['keyPassword']\n        }\n    }\n    buildTypes {", 1)
    s = s.replace("        release {\n            minifyEnabled false", "        release {\n            signingConfig signingConfigs.release\n            minifyEnabled false", 1)
    assert 'signingConfig signingConfigs.release' in s, 'build.gradle mudou de formato'
    open(p, 'w').write(s)
import re
s = open(p).read()
s = re.sub(r'versionCode \d+', 'versionCode 3', s); s = re.sub(r'versionName "[^"]*"', 'versionName "1.2"', s)
open(p, 'w').write(s)
print('assinatura ok, versao 1.2 (3)')
