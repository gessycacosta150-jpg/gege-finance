# Desenha o ícone e a tela de abertura do app em todos os tamanhos do Android.
import glob, os
from PIL import Image, ImageDraw, ImageFont
R = 'android/app/src/main/res'
def fonte(px):
    for f in ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']:
        if os.path.exists(f): return ImageFont.truetype(f, px)
    return ImageFont.load_default(size=px)
PINK = (226, 68, 108, 255)
def moeda(S, escala, fundo=None, redondo=False, arred=False):
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if fundo:
        if redondo: d.ellipse([0, 0, S - 1, S - 1], fill=fundo)
        elif arred: d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * .22), fill=fundo)
        else: d.rectangle([0, 0, S, S], fill=fundo)
    c = S / 2; r = S * 0.30 * escala
    d.ellipse([c - r, c - r + S * 0.02 * escala, c + r, c + r + S * 0.02 * escala], fill=(170, 40, 75, 255))
    d.ellipse([c - r, c - r, c + r, c + r], fill=(255, 201, 74, 255))
    d.ellipse([c - r * .8, c - r * .8, c + r * .8, c + r * .8], outline=(230, 160, 30, 255), width=max(1, int(S * .018 * escala)))
    f = fonte(int(S * .25 * escala)); t = 'R$'; b = d.textbbox((0, 0), t, font=f)
    d.text((c - (b[2] - b[0]) / 2 - b[0], c - (b[3] - b[1]) / 2 - b[1]), t, font=f, fill=(120, 30, 55, 255))
    return im
def hi(S, **k): return moeda(S * 4, **k).resize((S, S), Image.LANCZOS)
for dn, m in {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}.items():
    L, FG = int(48 * m), int(108 * m)
    hi(L, escala=1.25, fundo=PINK, arred=True).save(f'{R}/mipmap-{dn}/ic_launcher.png')
    hi(L, escala=1.25, fundo=PINK, redondo=True).save(f'{R}/mipmap-{dn}/ic_launcher_round.png')
    hi(FG, escala=.85).save(f'{R}/mipmap-{dn}/ic_launcher_foreground.png')
for f in glob.glob(f'{R}/drawable*/splash.png'):
    w, h = Image.open(f).size; im = Image.new('RGBA', (w, h), (255, 246, 241, 255)); s = int(min(w, h) * .45)
    ic = hi(s, escala=1.25, fundo=PINK, arred=True); im.paste(ic, ((w - s) // 2, (h - s) // 2), ic); im.convert('RGB').save(f)
open(f'{R}/values/ic_launcher_background.xml', 'w').write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#E2446C</color>\n</resources>\n')
for dn, m in {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}.items():
    S = int(24 * m); big = Image.new('RGBA', (S * 4, S * 4), (0, 0, 0, 0)); d = ImageDraw.Draw(big); c = S * 2; r = S * 1.8
    d.ellipse([c - r, c - r, c + r, c + r], outline=(255, 255, 255, 255), width=int(S * .28))
    f = fonte(int(S * 1.6)); b = d.textbbox((0, 0), 'R$', font=f); d.text((c - (b[2] - b[0]) / 2 - b[0], c - (b[3] - b[1]) / 2 - b[1]), 'R$', font=f, fill=(255, 255, 255, 255))
    os.makedirs(f'{R}/drawable-{dn}', exist_ok=True); big.resize((S, S), Image.LANCZOS).save(f'{R}/drawable-{dn}/ic_stat_gege.png')
os.makedirs('www/icons', exist_ok=True); hi(192, escala=1.25, fundo=PINK, arred=True).save('www/icons/icon-192.png')
print('icones ok')
