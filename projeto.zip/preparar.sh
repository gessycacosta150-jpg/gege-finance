#!/usr/bin/env bash
# Monta o projeto Android a partir dos arquivos do app. Usado pela tarefa "Gerar APK".
set -euo pipefail
npm install
mkdir -p www/lib
cp node_modules/pdfjs-dist/build/pdf.min.js node_modules/pdfjs-dist/build/pdf.worker.min.js www/lib/
cp node_modules/xlsx/dist/xlsx.full.min.js www/lib/
[ -d android ] || npx cap add android
pip install --quiet pillow
python3 extra/icones.py
cp extra/contas.keystore extra/keystore.properties android/app/
python3 extra/assinatura.py
npx cap sync android
